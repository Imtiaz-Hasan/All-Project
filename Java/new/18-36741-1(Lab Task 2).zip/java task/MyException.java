import java.lang.*;

public class MyException extends Exception
{
	public String getMessage(){return "user";}
}