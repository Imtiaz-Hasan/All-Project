package interfaces;
import java.lang.*;
import classes.*;
public interface IAmount
{
	void addAmount(int amount);
	void sellAmount(int amount);
}