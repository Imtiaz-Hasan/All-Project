import java.lang.*;

public class MyClass extends FinalDemo
{
	public void show(){System.out.println("MyClass-Show");}
}