import java.lang.*;
import Frames.*;

public class Start
{
	public static void main(String args[])
	{
		Home hm = new Home();
		hm.setVisible(true);
	}
}