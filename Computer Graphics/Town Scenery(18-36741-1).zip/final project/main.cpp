#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <cmath>
#include <windows.h>

float car1 = 0.00f;
float speed1 = 0.0025f;

float car2 = 0.00f;
float speed2 = 0.0025f;

float train1 = 0.00f;
float trainspeed = 0.0025f;

float sun = 1.00f;
float cloud1 = 0.00f;
float cloud2 = 0.00f;


void position_car1(int value) {
    if(speed1>1.00f || speed1<0.00f)
    {
        speed1 = 0.0f;
    }
    car1 += speed1;
    if(car1-1.3 > 1.0)
    {
        car1 = -1.0;
    }
	glutPostRedisplay();

	glutTimerFunc(20, position_car1, 0);
}

void position_car2(int value) {
    if(speed2>1 || speed2<0)
    {
        speed2 = 0.0f;
    }
    car2 -= speed2;
    if(car2+1.3 < -1.0)
    {
        car2 = 1.5;
    }
	glutPostRedisplay();

	glutTimerFunc(20, position_car2, 0);
}

void position_train(int value) {
    if(trainspeed>1 || trainspeed<0)
    {
        trainspeed = 0.0f;
    }
    train1 -= trainspeed;
    if(train1+1.3 < -1.0)
    {
        train1 = 1.0;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(20, position_train, 0); //Notify GLUT to call update again in 25 milliseconds
}

void position_sun(int value){
    sun -= 0.00055f;
    if(sun+1.0 < -1.0)
    {
        sun = 1.3;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(20, position_sun, 0);
}

void position_cloud1(int value) {
    cloud1 += 0.0025f;
    if(cloud1-1.3 > 1.0)
    {
        cloud1 = -1.0;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(50, position_cloud1, 0); //Notify GLUT to call update again in 25 milliseconds
}

void position_cloud2(int value){
    cloud2 -= 0.0025f;
    if(cloud2+1.3 < -1.0)
    {
        cloud2 = 1.0;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(70, position_cloud2, 0);
}

void specialKeys(int key, int x, int y) {
    switch (key) {
      case GLUT_KEY_UP:
          position_car1(0);
          position_car2(0);
          position_train(0);
          break;
      case GLUT_KEY_DOWN:
          exit(0);
          break;
    }
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
      case 81:
          speed1+=0.0025f;
          position_car1(0);
          break;
      case 87:
          speed1-=0.0025f;
          position_car1(0);
          break;
      case 65:
          speed2+=0.0025f;
          position_car2(0);
          break;
      case 83:
          speed2-=0.0025f;
          position_car2(0);
          break;
      case 69:
          trainspeed+=0.0025f;
          position_train(0);
          break;
      case 82:
          trainspeed-=0.0025f;
          position_train(0);
          break;
    }
}

void sky(){
    //Sky
    if(sun<=1.00f && sun>=0.90f){
        glClear (GL_COLOR_BUFFER_BIT);
        glBegin(GL_QUADS);
        glColor3ub(255, 255, 51);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }
    else if(sun<0.90f && sun>=0.55f){
        glBegin(GL_QUADS);
        glColor3f(0.000, 0.749, 1.000);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.8, 1.000, 1.000);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }
    else if(sun<0.55f && sun>=0.35f){
        glBegin(GL_QUADS);
        glColor3ub(255, 255, 0);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(1.000, 0.961, 0.933);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }

    else if(sun<0.35f && sun>=0.25f){
        glBegin(GL_QUADS);
        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(1.000, 0.855, 0.725);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }

    else if(sun<0.25f && sun>=0.10f){
        glBegin(GL_QUADS);
        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.957, 0.643, 0.376);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }
    else if(sun<0.10f && sun>=-0.10f){
        glBegin(GL_QUADS);
        glColor3f(1.000, 0.388, 0.278);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.957, 0.643, 0.376);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();
    }
    else{
        glBegin(GL_QUADS);
        glColor3f(0.412, 0.412, 0.412);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.8, 1.000, 1.000);
        glVertex2f(1.0, -0.05);
        glVertex2f(-1.0, -0.05);
        glEnd();

        glPushMatrix();
        glTranslatef(0.0f, sun, 0.0f);
        glTranslatef(0.80,1.05,0);
        glScalef(0.6,1,1);
        glColor3f(0.902, 0.902, 0.980);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }
}

void field()
{
    glBegin(GL_POLYGON);
    glColor3ub(0, 128, 29);
    glVertex2f(-1.0f,-0.05f);
    glVertex2f(1.0f,-0.05f);
    glVertex2f(1.0f,0.25);
    glVertex2f(-1.0f,0.25);
    glEnd();

}

void rail_line(){
    //Rail line
    glBegin(GL_QUADS);
    glColor3f(0.46,0.47,0.46);
    glVertex2f(-1.0, 0.015);
    glVertex2f(-1.0, 0.030);
    glVertex2f(1.0, 0.030);
    glVertex2f(1.0, 0.015);

    glColor3f(0.46,0.47,0.46);
    glVertex2f(-1.0, 0.050);
    glVertex2f(-1.0, 0.065);
    glVertex2f(1.0, 0.065);
    glVertex2f(1.0, 0.050);

    glColor3f(0.0,0.0,0.0);
    for(float i = -0.99; i<=1; i =i+0.03){     //rail line divider
        glVertex2f(i,0.030);
        glVertex2f(i,0.050);
        glVertex2f(i+0.01, 0.050);
        glVertex2f(i+0.01, 0.030);
    }
    glEnd();
}

void train()
{
    //Train 1
	glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glColor3ub(26, 83, 255);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.05, 0.05);
        glVertex2f(0.20, 0.05);
        glVertex2f(0.20, 0.16);
        glVertex2f(0.05, 0.16);
	glEnd();
    glPopMatrix();
    //shed
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(217, 217, 217);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.05, 0.16);
        glVertex2f(0.20, 0.16);
        glVertex2f(0.20, 0.18);
        glVertex2f(0.05, 0.18);
	glEnd();
    glPopMatrix();
    //window
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.07, 0.09);
        glVertex2f(0.10, 0.09);
        glVertex2f(0.10, 0.13);
        glVertex2f(0.07, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.11, 0.09);
        glVertex2f(0.15, 0.09);
        glVertex2f(0.15, 0.13);
        glVertex2f(0.11, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.16, 0.09);
        glVertex2f(0.19, 0.09);
        glVertex2f(0.19, 0.13);
        glVertex2f(0.16, 0.13);
	glEnd();
    glPopMatrix();
    //chain
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(217, 217, 217);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.20, 0.09);
        glVertex2f(0.25, 0.09);
        glVertex2f(0.25, 0.10);
        glVertex2f(0.20, 0.10);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.08,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.17,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

//Train 2
    glPushMatrix();
    glColor3ub(26, 83, 255);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.25, 0.05);
        glVertex2f(0.40, 0.05);
        glVertex2f(0.40, 0.16);
        glVertex2f(0.25, 0.16);
	glEnd();
    glPopMatrix();

     glPushMatrix();
    glColor3ub(217, 217, 217);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.25, 0.16);
        glVertex2f(0.40, 0.16);
        glVertex2f(0.40, 0.18);
        glVertex2f(0.25, 0.18);
	glEnd();
    glPopMatrix();

    //window
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.27, 0.09);
        glVertex2f(0.30, 0.09);
        glVertex2f(0.30, 0.13);
        glVertex2f(0.27, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.31, 0.09);
        glVertex2f(0.34, 0.09);
        glVertex2f(0.34, 0.13);
        glVertex2f(0.31, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.35, 0.09);
        glVertex2f(0.38, 0.09);
        glVertex2f(0.38, 0.13);
        glVertex2f(0.35, 0.13);
	glEnd();
    glPopMatrix();

    //chain
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(217, 217, 217);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.40, 0.09);
        glVertex2f(0.45, 0.09);
        glVertex2f(0.45, 0.10);
        glVertex2f(0.40, 0.10);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.28,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.37,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();


//train 3
    glPushMatrix();
    glColor3ub(26, 83, 255);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.45, 0.05);
        glVertex2f(0.65, 0.05);
        glVertex2f(0.65, 0.16);
        glVertex2f(0.45, 0.16);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(217, 217, 217);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.45, 0.16);
        glVertex2f(0.65, 0.16);
        glVertex2f(0.65, 0.18);
        glVertex2f(0.45, 0.18);
	glEnd();
    glPopMatrix();

    //window
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.47, 0.09);
        glVertex2f(0.50, 0.09);
        glVertex2f(0.50, 0.13);
        glVertex2f(0.47, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.51, 0.09);
        glVertex2f(0.54, 0.09);
        glVertex2f(0.54, 0.13);
        glVertex2f(0.51, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.55, 0.09);
        glVertex2f(0.58, 0.09);
        glVertex2f(0.58, 0.13);
        glVertex2f(0.55, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.59, 0.09);
        glVertex2f(0.63, 0.09);
        glVertex2f(0.63, 0.13);
        glVertex2f(0.59, 0.13);
	glEnd();
    glPopMatrix();

    //chain
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(217, 217, 217);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.65, 0.09);
        glVertex2f(0.70, 0.09);
        glVertex2f(0.70, 0.10);
        glVertex2f(0.65, 0.10);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.48,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.62,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
//train 4
    glPushMatrix();
    glColor3ub(26, 83, 255);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.70, 0.05);
        glVertex2f(0.85, 0.05);
        glVertex2f(0.85, 0.16);
        glVertex2f(0.70, 0.16);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3ub(217, 217, 217);
    glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.70, 0.16);
        glVertex2f(0.85, 0.16);
        glVertex2f(0.85, 0.18);
        glVertex2f(0.70, 0.18);
	glEnd();
    glPopMatrix();

    //window
    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.72, 0.09);
        glVertex2f(0.75, 0.09);
        glVertex2f(0.75, 0.13);
        glVertex2f(0.72, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.76, 0.09);
        glVertex2f(0.79, 0.09);
        glVertex2f(0.79, 0.13);
        glVertex2f(0.76, 0.13);
	glEnd();
    glPopMatrix();

    glLoadIdentity(); //Reset the drawing perspective
	glPushMatrix();
	glColor3ub(242, 242, 242);
	glTranslatef(train1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(0.80, 0.09);
        glVertex2f(0.83, 0.09);
        glVertex2f(0.83, 0.13);
        glVertex2f(0.80, 0.13);
	glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.73,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(train1, 0.0f, 0.0f);
        glTranslatef(0.82,0.060,0);
        glScalef(0.6,1,1);
        glColor3f(0.13,0.13,0.13);
        glColor3f(0.13,0.13,0.13);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
        if(sun<-0.10){
            glColor3f(1.000, 0.973, 0.863);
            glPushMatrix();
            glTranslatef(train1, 0.0f, 0.0f);
            glBegin(GL_POLYGON);
                glVertex2f(0.05, 0.145);
                glVertex2f(0.05, 0.155);
                glVertex2f(-0.00, 0.16);
                glVertex2f(-0.00, 0.14);
            glEnd();
            glPopMatrix();
        }
        glutSwapBuffers();
}

void sun1(){
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    if(sun<=1.00 && sun>=0.95f){
       glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.647, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(sun<0.95f && sun>=0.85f){
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.843, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(sun<0.85 && sun>=0.65){
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(sun<0.65 && sun>=0.45){
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.843, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(sun<0.45 && sun>=0.25){
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3ub(1.000, 0.647, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(sun<0.25 && sun>=0.10){
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.549, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else{
        glPushMatrix();
        glTranslatef(0.75f, sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.271, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }
}

void cloud_left(){
    //Cloud on the left
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.78,0.82,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.74,0.87,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.70,0.91,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.65,0.88,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.07;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.61,0.80,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.68,0.77,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud1, 0.0f, 0.0f);
        glTranslatef(-0.75,0.78,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
}
void cloud_middle(){
    //Cloud on the left
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.58,0.52,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.54,0.57,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.50,0.61,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.45,0.58,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.07;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.41,0.50,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.48,0.47,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(0.0f, 0.0f, 0.0f);
        glTranslatef(-0.55,0.48,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
}

void cloud_right(){
    //Cloud on the right
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.78,0.70,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.74,0.75,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.70,0.79,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.65,0.76,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.07;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.61,0.76,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.68,0.65,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.63,0.66,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(cloud2, 0.0f, 0.0f);
        glTranslatef(0.75,0.66,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
}


void road()
{

    glBegin(GL_QUADS);
    glColor3ub(122, 122, 82);
    glVertex2f(-1.0, -0.02);
    glVertex2f(-1.0, -0.28);
    glVertex2f(1.0, -0.28);
    glVertex2f(1.0, -0.02);

    glBegin(GL_QUADS);
    glColor3ub(245, 245, 240);
    glVertex2f(-1.0, -0.28);
    glVertex2f(-1.0, -0.32);
    glVertex2f(1.0, -0.32);
    glVertex2f(1.0, -0.28);

    glBegin(GL_QUADS);
    glColor3ub(122, 122, 82);
    glVertex2f(-1.0, -0.32);
    glVertex2f(-1.0, -0.58);
    glVertex2f(1.0, -0.58);
    glVertex2f(1.0, -0.32);

    glEnd();
}

void car_1()
{
    glColor3ub(255, 255, 0);
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.85, -0.20);
        glVertex2f(-0.55, -0.20);
        glVertex2f(-0.55, -0.15);
        glVertex2f(-0.60, -0.14);
        glVertex2f(-0.65, -0.07);
        glVertex2f(-0.75, -0.07);
        glVertex2f(-0.80, -0.07);
        glVertex2f(-0.85, -0.15);

    glEnd();
    glPopMatrix();

    glColor3f(0.0, 0.0, 0.0);
    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.61, -0.13);
        glVertex2f(-0.66, -0.04);
        glVertex2f(-0.79, -0.04);
        glVertex2f(-0.84, -0.13);
    glEnd();
    glPopMatrix();

   glColor3ub(255, 255, 0);
    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.73, -0.15);
        glVertex2f(-0.72, -0.15);
        glVertex2f(-0.72, -0.04);
        glVertex2f(-0.73, -0.04);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
        glTranslatef(-0.80,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 0.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.03;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
        glTranslatef(-0.80,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.01;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
        glTranslatef(-0.62,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 0.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.03;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car1, 0.0f, 0.0f);
        glTranslatef(-0.62,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.01;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    if(sun<-0.10){
        glColor3f(1.000, 0.973, 0.863);
        glPushMatrix();
        glTranslatef(car1, 0.0f, 0.0f);
        glBegin(GL_POLYGON);
            glVertex2f(-0.55, -0.165);
            glVertex2f(-0.55, -0.175);
            glVertex2f(-0.505, -0.195);
            glVertex2f(-0.505, -0.145);
        glEnd();
        glPopMatrix();
    }

    glutSwapBuffers();
}
void car_2()
{
    glColor3ub(255, 0, 0);
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.40, -0.20);
        glVertex2f(-0.08, -0.20);
        glVertex2f(-0.08, -0.15);
        glVertex2f(-0.10, -0.14);
        glVertex2f(-0.15, -0.07);
        glVertex2f(-0.30, -0.07);
        glVertex2f(-0.20, -0.07);
        glVertex2f(-0.40, -0.15);

    glEnd();
    glPopMatrix();

    glColor3f(0.0, 0.0, 0.0);
    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.11, -0.13);
        glVertex2f(-0.16, -0.04);
        glVertex2f(-0.29, -0.04);
        glVertex2f(-0.34, -0.13);
    glEnd();
    glPopMatrix();

   glColor3ub(255, 0, 0);
    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.23, -0.15);
        glVertex2f(-0.22, -0.15);
        glVertex2f(-0.22, -0.04);
        glVertex2f(-0.23, -0.04);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
        glTranslatef(-0.30,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 0.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.03;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
        glTranslatef(-0.30,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.01;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
        glTranslatef(-0.11,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 0.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.03;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(car2, 0.0f, 0.0f);
        glTranslatef(-0.11,-0.21,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.01;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    if(sun<-0.10)
        {
        glColor3f(1.000, 0.973, 0.863);
        glPushMatrix();
        glTranslatef(car2, 0.0f, 0.0f);
        glBegin(GL_POLYGON);
            glVertex2f(-0.45, -0.15);
            glVertex2f(-0.45, -0.20);
            glVertex2f(-0.325, -0.145);
            glVertex2f(-0.384, -0.145);
        glEnd();
        glPopMatrix();
    }

    glutSwapBuffers();
}

void footpath()
{
    glBegin(GL_QUADS);
    glColor3f(0.753, 0.753, 0.753);
    glVertex2f(-1.0, -0.50);
    glVertex2f(-1.0, -0.57);
    glVertex2f(1.0, -0.57);
    glVertex2f(1.0, -0.50);
}

void building1(){
    //House
    glBegin(GL_QUADS);
    glColor3ub(255, 209, 26);
    glVertex2f(0.60, -0.03);
    glVertex2f(0.80, -0.03);
    glVertex2f(0.80, 0.35);
    glVertex2f(0.60, 0.35);

    //Door
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.894, 0.882);
    glVertex2f(0.72, -0.03);
    glVertex2f(0.77, -0.03);
    glVertex2f(0.77, 0.12);
    glVertex2f(0.72, 0.12);

    //Window

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.64, 0.03);
    glVertex2f(0.68, 0.03);
    glVertex2f(0.68, 0.10);
    glVertex2f(0.64, 0.10);

    //window
    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.64, 0.22);
    glVertex2f(0.68, 0.22);
    glVertex2f(0.68, 0.29);
    glVertex2f(0.64, 0.29);

    glBegin(GL_QUADS);
    glColor3f(1.000, 0.894, 0.882);
    glVertex2f(0.72, 0.22);
    glVertex2f(0.77, 0.22);
    glVertex2f(0.77, 0.29);
    glVertex2f(0.72, 0.29);

    //Basement
    glBegin(GL_QUADS);
    glColor3f(0.647, 0.165, 0.165);
    glVertex2f(0.58, -0.05);
    glVertex2f(0.82, -0.05);
    glVertex2f(0.82, -0.03);
    glVertex2f(0.58, -0.03);

    //Roof
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(0.60, 0.15);
    glVertex2f(0.80, 0.15);
    glVertex2f(0.80, 0.17);
    glVertex2f(0.60, 0.17);
    glEnd();

    //Roof
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(0.59, 0.35);
    glVertex2f(0.81, 0.35);
    glVertex2f(0.81, 0.37);
    glVertex2f(0.59, 0.37);

    glEnd();

}

void building2(){
    //House 2
    glBegin(GL_QUADS);
    glColor3ub(51, 153, 102);
    glVertex2f(0.25, -0.03);
    glVertex2f(0.50, -0.03);
    glVertex2f(0.50, 0.50);
    glVertex2f(0.25, 0.50);


    //window of house 2
    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.29, 0.21);
    glVertex2f(0.33, 0.21);
    glVertex2f(0.33, 0.28);
    glVertex2f(0.29, 0.28);

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.40, 0.21);
    glVertex2f(0.45, 0.21);
    glVertex2f(0.45, 0.28);
    glVertex2f(0.40, 0.28);

    //Window of House 1

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.29, 0.03);
    glVertex2f(0.33, 0.03);
    glVertex2f(0.33, 0.10);
    glVertex2f(0.29, 0.10);

    //Window of House 1

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.29, 0.36);
    glVertex2f(0.33, 0.36);
    glVertex2f(0.33, 0.43);
    glVertex2f(0.29, 0.43);

     //Window of House 1

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.40, 0.36);
    glVertex2f(0.45, 0.36);
    glVertex2f(0.45, 0.43);
    glVertex2f(0.40, 0.43);

    //Door of House 2
    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(0.40, -0.03);
    glVertex2f(0.45, -0.03);
    glVertex2f(0.45, 0.12);
    glVertex2f(0.40, 0.12);

     //Roof of house 1
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(0.25, 0.15);
    glVertex2f(0.50, 0.15);
    glVertex2f(0.50, 0.17);
    glVertex2f(0.25, 0.17);
    glEnd();

    //Roof of house 1
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(0.25, 0.30);
    glVertex2f(0.50, 0.30);
    glVertex2f(0.50, 0.32);
    glVertex2f(0.25, 0.32);
    glEnd();

     //Roof of house 1
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(0.24, 0.49);
    glVertex2f(0.51, 0.49);
    glVertex2f(0.51, 0.51);
    glVertex2f(0.24, 0.51);
    glEnd();

    //Basement of house 2
    glBegin(GL_QUADS);
    glColor3f(0.647, 0.165, 0.165);
    glVertex2f(0.24, -0.05);
    glVertex2f(0.51, -0.05);
    glVertex2f(0.51, -0.03);
    glVertex2f(0.24, -0.03);


}

void building3(){
    //House 2
    glBegin(GL_QUADS);
    glColor3ub(210, 121, 166);
    glVertex2f(-0.25, -0.03);
    glVertex2f(-0.50, -0.03);
    glVertex2f(-0.50, 0.50);
    glVertex2f(-0.25, 0.50);


    //window of house 3
    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.29, 0.21);
    glVertex2f(-0.33, 0.21);
    glVertex2f(-0.33, 0.28);
    glVertex2f(-0.29, 0.28);

    //Window of House 3

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.29, 0.03);
    glVertex2f(-0.33, 0.03);
    glVertex2f(-0.33, 0.10);
    glVertex2f(-0.29, 0.10);

    //Window of House 3

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.29, 0.36);
    glVertex2f(-0.33, 0.36);
    glVertex2f(-0.33, 0.43);
    glVertex2f(-0.29, 0.43);

     //Window of House 3

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.35, 0.36);
    glVertex2f(-0.40, 0.36);
    glVertex2f(-0.40, 0.43);
    glVertex2f(-0.35, 0.43);

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.35, 0.03);
    glVertex2f(-0.40, 0.03);
    glVertex2f(-0.40, 0.10);
    glVertex2f(-0.35, 0.10);

     glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.35, 0.21);
    glVertex2f(-0.40, 0.21);
    glVertex2f(-0.40, 0.28);
    glVertex2f(-0.35, 0.28);

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.42, 0.36);
    glVertex2f(-0.47, 0.36);
    glVertex2f(-0.47, 0.43);
    glVertex2f(-0.42, 0.43);

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.42, 0.03);
    glVertex2f(-0.47, 0.03);
    glVertex2f(-0.47, 0.10);
    glVertex2f(-0.42, 0.10);

    glBegin(GL_QUADS);
    glColor3f(1.000, 1.000, 1.000);
    glVertex2f(-0.42, 0.21);
    glVertex2f(-0.47, 0.21);
    glVertex2f(-0.47, 0.28);
    glVertex2f(-0.42, 0.28);


     //Roof of house 3
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(-0.25, 0.15);
    glVertex2f(-0.50, 0.15);
    glVertex2f(-0.50, 0.17);
    glVertex2f(-0.25, 0.17);
    glEnd();

    //Roof of house 1
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(-0.25, 0.30);
    glVertex2f(-0.50, 0.30);
    glVertex2f(-0.50, 0.32);
    glVertex2f(-0.25, 0.32);
    glEnd();

     //Roof of house 1
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.855, 0.725);
    glVertex2f(-0.24, 0.49);
    glVertex2f(-0.51, 0.49);
    glVertex2f(-0.51, 0.51);
    glVertex2f(-0.24, 0.51);
    glEnd();

    //Basement of house 2
    glBegin(GL_QUADS);
    glColor3f(0.647, 0.165, 0.165);
    glVertex2f(-0.24, -0.05);
    glVertex2f(-0.51, -0.05);
    glVertex2f(-0.51, -0.03);
    glVertex2f(-0.24, -0.03);


}
void building4()
{
    //House 1
    glBegin(GL_QUADS);
    glColor3ub(153, 153, 102);
    glVertex2f(-0.60, -0.03);
    glVertex2f(-0.70, -0.03);
    glVertex2f(-0.70, 0.60);
    glVertex2f(-0.60, 0.60);

     glBegin(GL_QUADS);
    glColor3ub(0, 102, 255);
    glVertex2f(-0.70, -0.03);
    glVertex2f(-0.80, -0.03);
    glVertex2f(-0.80, 0.50);
    glVertex2f(-0.70, 0.50);

    glBegin(GL_QUADS);
    glColor3ub(255, 102, 102);
    glVertex2f(-0.80, -0.03);
    glVertex2f(-0.95, -0.03);
    glVertex2f(-0.95, 0.40);
    glVertex2f(-0.80, 0.40);

    //windows

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.03);
    glVertex2f(-0.67, 0.03);
    glVertex2f(-0.67, 0.10);
    glVertex2f(-0.63, 0.10);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.12);
    glVertex2f(-0.67, 0.12);
    glVertex2f(-0.67, 0.19);
    glVertex2f(-0.63, 0.19);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.21);
    glVertex2f(-0.67, 0.21);
    glVertex2f(-0.67, 0.28);
    glVertex2f(-0.63, 0.28);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.30);
    glVertex2f(-0.67, 0.30);
    glVertex2f(-0.67, 0.37);
    glVertex2f(-0.63, 0.37);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.39);
    glVertex2f(-0.67, 0.39);
    glVertex2f(-0.67, 0.46);
    glVertex2f(-0.63, 0.46);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.63, 0.48);
    glVertex2f(-0.67, 0.48);
    glVertex2f(-0.67, 0.55);
    glVertex2f(-0.63, 0.55);

    //windows 2

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.73, 0.03);
    glVertex2f(-0.77, 0.03);
    glVertex2f(-0.77, 0.10);
    glVertex2f(-0.73, 0.10);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.73, 0.12);
    glVertex2f(-0.77, 0.12);
    glVertex2f(-0.77, 0.19);
    glVertex2f(-0.73, 0.19);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.73, 0.21);
    glVertex2f(-0.77, 0.21);
    glVertex2f(-0.77, 0.28);
    glVertex2f(-0.73, 0.28);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.73, 0.30);
    glVertex2f(-0.77, 0.30);
    glVertex2f(-0.77, 0.37);
    glVertex2f(-0.73, 0.37);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.73, 0.39);
    glVertex2f(-0.77, 0.39);
    glVertex2f(-0.77, 0.46);
    glVertex2f(-0.73, 0.46);

    //windows 3

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.83, 0.03);
    glVertex2f(-0.87, 0.03);
    glVertex2f(-0.87, 0.10);
    glVertex2f(-0.83, 0.10);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.83, 0.12);
    glVertex2f(-0.87, 0.12);
    glVertex2f(-0.87, 0.19);
    glVertex2f(-0.83, 0.19);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.83, 0.21);
    glVertex2f(-0.87, 0.21);
    glVertex2f(-0.87, 0.28);
    glVertex2f(-0.83, 0.28);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.83, 0.30);
    glVertex2f(-0.87, 0.30);
    glVertex2f(-0.87, 0.37);
    glVertex2f(-0.83, 0.37);


    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.89, 0.03);
    glVertex2f(-0.93, 0.03);
    glVertex2f(-0.93, 0.10);
    glVertex2f(-0.89, 0.10);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.89, 0.12);
    glVertex2f(-0.93, 0.12);
    glVertex2f(-0.93, 0.19);
    glVertex2f(-0.89, 0.19);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.89, 0.21);
    glVertex2f(-0.93, 0.21);
    glVertex2f(-0.93, 0.28);
    glVertex2f(-0.89, 0.28);

    glBegin(GL_QUADS);
    glColor3ub(242, 242, 242);
    glVertex2f(-0.89, 0.30);
    glVertex2f(-0.93, 0.30);
    glVertex2f(-0.93, 0.37);
    glVertex2f(-0.89, 0.37);


}




void road_lamp_another_side(){
    //Lam Stand - 1
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(-0.735, -0.50);
    glVertex2f(-0.720, -0.50);
    glVertex2f(-0.725, -0.25);
    glVertex2f(-0.730, -0.25);
    glEnd();

    //Lamp Stand - 1 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(-0.730, -0.25);
    glVertex2f(-0.705, -0.25);
    glVertex2f(-0.710, -0.22);
    glVertex2f(-0.728, -0.22);
    glEnd();

    //Lam Stand - 2
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(-0.435, -0.50);
    glVertex2f(-0.420, -0.50);
    glVertex2f(-0.425, -0.25);
    glVertex2f(-0.430, -0.25);
    glEnd();

    //Lamp Stand - 2 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(-0.430, -0.25);
    glVertex2f(-0.405, -0.25);
    glVertex2f(-0.410, -0.22);
    glVertex2f(-0.428, -0.22);
    glEnd();

    //Lam Stand - 3
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(-0.135, -0.50);
    glVertex2f(-0.120, -0.50);
    glVertex2f(-0.125, -0.25);
    glVertex2f(-0.130, -0.25);
    glEnd();

    //Lamp Stand - 3 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(-0.130, -0.25);
    glVertex2f(-0.105, -0.25);
    glVertex2f(-0.110, -0.22);
    glVertex2f(-0.128, -0.22);
    glEnd();

    //Lam Stand - 4
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(0.235, -0.50);
    glVertex2f(0.220, -0.50);
    glVertex2f(0.225, -0.25);
    glVertex2f(0.230, -0.25);
    glEnd();

    //Lamp Stand - 4 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(0.230, -0.25);
    glVertex2f(0.205, -0.25);
    glVertex2f(0.210, -0.22);
    glVertex2f(0.228, -0.22);
    glEnd();

    //Lam Stand - 5
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(0.535, -0.50);
    glVertex2f(0.520, -0.50);
    glVertex2f(0.525, -0.25);
    glVertex2f(0.530, -0.25);
    glEnd();

    //Lamp Stand - 5 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(0.530, -0.25);
    glVertex2f(0.505, -0.25);
    glVertex2f(0.510, -0.22);
    glVertex2f(0.528, -0.22);
    glEnd();

    //Lam Stand - 6
    glBegin(GL_POLYGON);
    glColor3f(0.34, 0.34, 0.34);
    glVertex2f(0.835, -0.50);
    glVertex2f(0.820, -0.50);
    glVertex2f(0.825, -0.25);
    glVertex2f(0.830, -0.25);
    glEnd();

    //Lamp Stand - 6 bulb
    glBegin(GL_POLYGON);
    glColor3f(1.000, 0.647, 0.000);
    glVertex2f(0.830, -0.25);
    glVertex2f(0.805, -0.25);
    glVertex2f(0.810, -0.22);
    glVertex2f(0.828, -0.22);
    glEnd();
}

void field_2()
{

    glEnd();
    glBegin(GL_QUADS);
    glColor3ub(51, 153, 51);
    glVertex2f(1.0, -0.57);

    glColor3ub(51, 153, 51);
    glVertex2f(-1.0, -0.57);

    glColor3f(0.486, 0.988, 0.000);
    glVertex2f(-1.0, -1.0);

    glColor3ub(0, 255, 0);
    glVertex2f(1.0, -1.0);
    glEnd();

}

void park(){

    //park path
    glBegin(GL_QUADS);
    glColor3f(1.000, 0.871, 0.678);
    glVertex2f(-1.0, -0.73);
    glColor3f(1.000, 0.894, 0.769);
    glVertex2f(1.0, -0.73);
    glColor3f(1.000, 0.922, 0.804);
    glVertex2f(1.0, -0.77);
    glColor3f(0.871, 0.722, 0.529);
    glVertex2f(-1.0, -0.77);

    glEnd();

}


void park_tree(){
    //Park Tree 1
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.84, -0.65);
    glVertex2f(-0.81, -0.65);
    glVertex2f(-0.82, -0.45);
    glVertex2f(-0.83, -0.45);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.88, -0.50);
    glVertex2f(-0.77, -0.50);
    glVertex2f(-0.825, -0.30);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.88, -0.47);
    glVertex2f(-0.77, -0.47);
    glVertex2f(-0.825, -0.29);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.88, -0.44);
    glVertex2f(-0.77, -0.44);
    glVertex2f(-0.825, -0.27);
    glEnd();

    //tree 7

    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.74, -0.95);
    glVertex2f(-0.71, -0.95);
    glVertex2f(-0.72, -0.75);
    glVertex2f(-0.73, -0.75);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.77, -0.80);
    glVertex2f(-0.66, -0.80);
    glVertex2f(-0.725, -0.60);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.77, -0.77);
    glVertex2f(-0.66, -0.77);
    glVertex2f(-0.725, -0.59);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.77, -0.74);
    glVertex2f(-0.66, -0.74);
    glVertex2f(-0.725, -0.57);
    glEnd();

    //tree 8
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.44, -0.95);
    glVertex2f(-0.41, -0.95);
    glVertex2f(-0.42, -0.75);
    glVertex2f(-0.43, -0.75);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.47, -0.80);
    glVertex2f(-0.36, -0.80);
    glVertex2f(-0.425, -0.60);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.47, -0.77);
    glVertex2f(-0.36, -0.77);
    glVertex2f(-0.425, -0.59);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.47, -0.74);
    glVertex2f(-0.36, -0.74);
    glVertex2f(-0.425, -0.57);
    glEnd();

    //tree 9
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.04, -0.95);
    glVertex2f(-0.01, -0.95);
    glVertex2f(-0.02, -0.75);
    glVertex2f(-0.03, -0.75);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.09, -0.80);
    glVertex2f(0.06, -0.80);
    glVertex2f(-0.025, -0.60);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.09, -0.77);
    glVertex2f(0.06, -0.77);
    glVertex2f(-0.025, -0.59);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(-0.09, -0.74);
    glVertex2f(0.06, -0.74);
    glVertex2f(-0.025, -0.57);
    glEnd();

    //tree 10

    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.44, -0.95);
    glVertex2f(0.41, -0.95);
    glVertex2f(0.42, -0.75);
    glVertex2f(0.43, -0.75);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.49, -0.80);
    glVertex2f(0.36, -0.80);
    glVertex2f(0.425, -0.60);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.49, -0.77);
    glVertex2f(0.36, -0.77);
    glVertex2f(0.425, -0.59);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.49, -0.74);
    glVertex2f(0.36, -0.74);
    glVertex2f(0.425, -0.57);
    glEnd();

    //tree 11
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.74, -0.95);
    glVertex2f(0.71, -0.95);
    glVertex2f(0.72, -0.75);
    glVertex2f(0.73, -0.75);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.79, -0.80);
    glVertex2f(0.66, -0.80);
    glVertex2f(0.725, -0.60);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.79, -0.77);
    glVertex2f(0.66, -0.77);
    glVertex2f(0.725, -0.59);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 153, 0);
    glVertex2f(0.79, -0.74);
    glVertex2f(0.66, -0.74);
    glVertex2f(0.725, -0.57);
    glEnd();


    //Park Tree 2
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.59, -0.65);
    glVertex2f(-0.56, -0.65);
    glVertex2f(-0.57, -0.45);
    glVertex2f(-0.58, -0.45);
    glEnd();

    glPushMatrix();
        glTranslatef(-0.595,-0.45,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.555,-0.45,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.575,-0.385,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    //Park Tree 3
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.34, -0.65);
    glVertex2f(-0.31, -0.65);
    glVertex2f(-0.32, -0.45);
    glVertex2f(-0.33, -0.45);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.38, -0.50);
    glVertex2f(-0.27, -0.50);
    glVertex2f(-0.325, -0.30);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.38, -0.47);
    glVertex2f(-0.27, -0.47);
    glVertex2f(-0.325, -0.29);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(-0.38, -0.44);
    glVertex2f(-0.27, -0.44);
    glVertex2f(-0.325, -0.27);
    glEnd();

     //Park Tree 4
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.34, -0.65);
    glVertex2f(0.31, -0.65);
    glVertex2f(0.32, -0.45);
    glVertex2f(0.33, -0.45);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.40, -0.50);
    glVertex2f(0.25, -0.50);
    glVertex2f(0.325, -0.30);
    glEnd();

     glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.40, -0.47);
    glVertex2f(0.25, -0.47);
    glVertex2f(0.325, -0.29);
    glEnd();

     glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.40, -0.44);
    glVertex2f(0.25, -0.44);
    glVertex2f(0.325, -0.27);
    glEnd();

    //Park Tree 5
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.59, -0.65);
    glVertex2f(0.56, -0.65);
    glVertex2f(0.57, -0.45);
    glVertex2f(0.58, -0.45);
    glEnd();


    glPushMatrix();
        glTranslatef(0.595,-0.45,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.555,-0.45,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.575,-0.385,0);
        glScalef(0.6,1,1);
        glColor3ub(255, 133, 51);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    //Park Tree 5
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.84, -0.65);
    glVertex2f(0.81, -0.65);
    glVertex2f(0.82, -0.45);
    glVertex2f(0.83, -0.45);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.88, -0.50);
    glVertex2f(0.77, -0.50);
    glVertex2f(0.825, -0.30);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.88, -0.47);
    glVertex2f(0.77, -0.47);
    glVertex2f(0.825, -0.29);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(0, 204, 0);
    glVertex2f(0.88, -0.44);
    glVertex2f(0.77, -0.44);
    glVertex2f(0.825, -0.27);
    glEnd();
}

void myDisplay(void){
    glLoadIdentity();
    sky();
    sun1();
    field();
    rail_line();
    train();
    cloud_left();
    cloud_right();
    cloud_middle();
    building1();
    building2();
    building3();
    building4();
    road();
    car_1();
    car_2();
    road_lamp_another_side();
    footpath();
    field_2();
    park();
    park_tree();
    glFlush();
}

void sound()
{

    PlaySound("a.wav", NULL,SND_ASYNC|SND_FILENAME|SND_LOOP);

}


void myInit (void){
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0f, 0.0f, 0.0f);
    glPointSize(4.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
}

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1366, 768);
    glutInitWindowPosition (0, 0);
    glutCreateWindow ("Town Scenery");
    glutDisplayFunc(myDisplay);
    glutSpecialFunc(specialKeys);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(20, position_sun, 0);
    glutTimerFunc(20, position_cloud1, 0);
    glutTimerFunc(20, position_cloud2, 0);
    sound();
    myInit ();
    glutMainLoop();
}
